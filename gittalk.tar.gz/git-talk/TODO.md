[ ] add email to setup
[x] create git commit message hook
[x] enable wrapper code
[ ] function to write the actual hook
[x] write git root finder function
[ ] print --> stdout + stderr
[ ] GUI dialog flow design
[ ] GUI dialogs code
