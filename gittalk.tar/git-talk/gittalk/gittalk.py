class GitTalk(object):
    def __init__(self, *args, **kwargs):
        pass

    def enable(self):
        pass

    def disable(self):
        pass

    def trigger(self):
        pass
